package com.jonseba.user

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import androidx.credentials.CredentialManager
import androidx.credentials.GetCredentialRequest
import androidx.credentials.CustomCredential
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore

class MainActivity : ComponentActivity() {
    private val auth by lazy { FirebaseAuth.getInstance() }
    private val db by lazy { FirebaseFirestore.getInstance() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { UserScreen(
            onGoogleLogin = { signInWithGoogle() },
            onLogout = { auth.signOut(); recreate() },
            email = auth.currentUser?.email
        ) }
    }

    private fun signInWithGoogle() {
        val clientId = getString(R.string.default_web_client_id)
        if (clientId.startsWith("PASTE_")) return
        val googleOption = GetGoogleIdOption.Builder()
            .setFilterByAuthorizedAccounts(false)
            .setServerClientId(clientId)
            .setAutoSelectEnabled(false)
            .build()
        val request = GetCredentialRequest.Builder()
            .addCredentialOption(googleOption).build()
        val manager = CredentialManager.create(this)
        lifecycleScope.launch {
            try {
                val result = manager.getCredential(this@MainActivity, request)
                val credential = result.credential
                if (credential is CustomCredential &&
                    credential.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                    val google = GoogleIdTokenCredential.createFrom(credential.data)
                    val firebaseCredential = GoogleAuthProvider.getCredential(google.idToken, null)
                    auth.signInWithCredential(firebaseCredential).addOnSuccessListener { task ->
                        val user = task.user ?: return@addOnSuccessListener
                        val ref = db.collection("users").document(user.uid)
                        ref.get().addOnSuccessListener { snap ->
                            if (!snap.exists()) {
                                val data = hashMapOf(
                                    "uid" to user.uid, "name" to user.displayName,
                                    "email" to user.email, "photoUrl" to user.photoUrl?.toString(),
                                    "status" to "active", "createdAt" to FieldValue.serverTimestamp()
                                )
                                ref.set(data).addOnSuccessListener { recreate() }
                            } else {
                                recreate()
                            }
                        }
                    }
                }
            } catch (_: Exception) { /* User cancelled or sign-in failed; UI remains available. */ }
        }
    }
}

@Composable
private fun UserScreen(onGoogleLogin: () -> Unit, onLogout: () -> Unit, email: String?) {
    var blocked by remember { mutableStateOf(false) }
    val user = FirebaseAuth.getInstance().currentUser
    LaunchedEffect(user?.uid) {
        if (user != null) FirebaseFirestore.getInstance().collection("users").document(user.uid)
            .addSnapshotListener { snap, _ -> blocked = snap?.getString("status") == "blocked" }
    }
    MaterialTheme {
        Surface(Modifier.fillMaxSize()) {
            Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center) {
                Text("জনসেবা লটারি", style = MaterialTheme.typography.headlineMedium)
                Spacer(Modifier.height(24.dp))
                when {
                    user == null -> Button(onClick = onGoogleLogin) { Text("Google দিয়ে লগইন") }
                    blocked -> {
                        Text("আপনার অ্যাকাউন্ট সাময়িকভাবে ব্লক করা হয়েছে। অ্যাডমিনের সাথে যোগাযোগ করুন।")
                        Spacer(Modifier.height(12.dp))
                        Button(onClick = onLogout) { Text("লগআউট") }
                    }
                    else -> {
                        Text("স্বাগতম, ${user.displayName ?: email ?: "ব্যবহারকারী"}")
                        Text("অ্যাকাউন্ট: সক্রিয়")
                        Spacer(Modifier.height(16.dp))
                        Text("এটি বিনামূল্যের ডেমো ড্র অ্যাপ।")
                        Spacer(Modifier.height(12.dp))
                        Button(onClick = onLogout) { Text("লগআউট") }
                    }
                }
            }
        }
    }
}
